# Workflow

## Review mode

Run `python scripts/run_pipeline.py --mode review --full FULL.png --background BACKGROUND.png --text TEXT.png --ocr OCR.json --registration registration.json --output-dir OUT`.

The state machine is `validate inputs → normalize line OCR → apply approved global mapping → validate page JSON → render PPTX → render PNG → test overflow → write QA`. Stop immediately on an invalid input, malformed OCR/registration, schema error, rendering error, or failed QA rule. A threshold-level issue completes the artifacts with `status: review`; a clean page uses `status: passed`; a failure returns nonzero and preserves `qa.json` with `status: failed`.

Registration JSON may include `line_corrections`, a map keyed by normalized
`line_id`. Entries may contain `dx`, `dy`, `width_delta`, `height_delta`,
`font_scale`, `reason`, and `source`. Geometry changes occur before the global
transform. Sources `manual` and `powerpoint` are retained as manual corrections;
other sources remain automatic. Limit each font-size step to 3% and cumulative
font-size drift to 8%.

Review checkpoints are the FULL image, geometry-locked text-free background, readable text image plus normalized lines, and final PPT render. Generated RGB/RGBA text images are valid. Review OCR accuracy and the approved transform when the text image drifts; do not approve a later checkpoint when an earlier one is unresolved.

## Batch mode

Use the same CLI with `--mode batch` for independently scheduled page jobs. Keep deterministic page order and a separate output directory per page. A failed page stops only that page; collect `review` pages for human inspection and continue the remaining jobs. Never promote `review` to `passed` merely to complete a batch.

Final acceptance requires readable images with identical positive dimensions, at least one OCR visual line, newline-free line values, one editable textbox per visual line, zero wrapping/merging/overflow, and separately traceable source, mapping, target, automatic-correction, and manual-correction data. Pixel extraction and high-precision registration are optional future advanced-mode steps, not V1 gates.
