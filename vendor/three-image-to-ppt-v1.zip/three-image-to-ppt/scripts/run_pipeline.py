#!/usr/bin/env python3
"""Run the V1 three-image review/batch page pipeline."""

from __future__ import annotations

import argparse
from dataclasses import replace
import json
from pathlib import Path
import subprocess
import sys
from typing import Any

PROJECT_ROOT = Path(__file__).parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.build_page_json import build_page_spec, write_page_spec
from scripts.map_text_coordinates import AffineTransform, map_lines
from scripts.normalize_ocr import normalize_ocr
from scripts.validate_inputs import validate_images

RENDER_SLIDES = Path(
    "/root/.codex/skills/builtins/presentations/container_tools/render_slides.py"
)
SLIDES_TEST = Path(
    "/root/.codex/skills/builtins/presentations/container_tools/slides_test.py"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("review", "batch"), required=True)
    for name in ("full", "background", "text", "ocr", "registration"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--page-id", default="page")
    return parser.parse_args()


def _write_qa(output_dir: Path, qa: dict[str, Any]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "qa.json").write_text(
        json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def _registration(path: Path) -> tuple[AffineTransform, dict[str, dict[str, Any]]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    matrix = payload["matrix"]
    if len(matrix) < 2 or any(len(row) < 3 for row in matrix[:2]):
        raise ValueError("registration matrix must contain two rows of three values")
    transform = AffineTransform(
        a=matrix[0][0], b=matrix[0][1], c=matrix[0][2],
        d=matrix[1][0], e=matrix[1][1], f=matrix[1][2],
        transform_id=payload["transform_id"],
    )
    corrections = payload.get("line_corrections", {})
    if not isinstance(corrections, dict):
        raise ValueError("line_corrections must be a map keyed by line_id")
    return transform, corrections


def _ocr_payload(path: Path) -> tuple[str, dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    for provider in ("canonical", "paddleocr-vl", "baidu"):
        if provider in payload:
            return provider, payload[provider]
    return "canonical", payload


def _qa_for_lines(
    lines: list[Any], mapped: list[Any] | None = None,
    page_width: int | None = None, page_height: int | None = None,
) -> dict[str, Any]:
    review_items = [
        {
            "rule": "ocr_line_confidence",
            "line_id": line.line_id,
            "value": line.confidence,
            "message": "OCR confidence is below the 0.95 pass threshold",
        }
        for line in lines
        if 0.80 <= line.confidence < 0.95
    ]
    failed_items = [
        {
            "rule": "ocr_line_confidence",
            "line_id": line.line_id,
            "value": line.confidence,
            "message": "OCR confidence is below the 0.80 failure threshold",
        }
        for line in lines
        if line.confidence < 0.80
    ]
    for item in mapped or []:
        if item.within_safe_area:
            continue
        box = item.mapped_bbox
        valid = box.width > 0 and box.height > 0
        on_slide = (
            valid and page_width is not None and page_height is not None
            and box.x >= 0 and box.y >= 0
            and box.x + box.width <= page_width
            and box.y + box.height <= page_height
        )
        finding = {
            "rule": "inside_safe_area", "line_id": item.line.line_id,
            "value": False,
            "message": "mapped line is outside the approved safe area",
        }
        (review_items if on_slide else failed_items).append(finding)
    status = "failed" if failed_items else "review" if review_items else "passed"
    return {
        "status": status,
        "review_items": review_items,
        "failed_items": failed_items,
        "checks": {"visual_line_count": len(lines), "newline_count": 0},
    }


def run(args: argparse.Namespace) -> int:
    args.output_dir.mkdir(parents=True, exist_ok=True)
    _remove_stale_outputs(args.output_dir)
    try:
        validation = validate_images(args.full, args.background, args.text)
        if not validation.valid:
            qa = {
                "status": "failed",
                "review_items": [],
                "failed_items": [
                    {"rule": "input_validation", "message": message}
                    for message in validation.errors
                ],
            }
            _write_qa(args.output_dir, qa)
            return 1

        provider, ocr_payload = _ocr_payload(args.ocr)
        lines = normalize_ocr(
            ocr_payload, provider, validation.width_px, validation.height_px
        )
        if not lines:
            _write_qa(
                args.output_dir,
                {
                    "status": "failed",
                    "review_items": [],
                    "failed_items": [
                        {
                            "rule": "ocr_line_count",
                            "value": 0,
                            "message": "OCR must contain at least one visual line",
                        }
                    ],
                },
            )
            return 1
        transform, line_corrections = _registration(args.registration)
        correction_errors = _validate_font_corrections(line_corrections)
        if correction_errors:
            qa = {"status": "failed", "review_items": [], "failed_items": correction_errors}
            _write_qa(args.output_dir, qa)
            return 1
        canvas_container = {
            "container_id": "canvas",
            "safe_bbox": {
                "x": 0,
                "y": 0,
                "width": validation.width_px,
                "height": validation.height_px,
            },
        }
        spec = build_page_spec(
            args.page_id,
            {"full": args.full, "background": args.background, "text": args.text},
            lines,
            transform,
            [canvas_container],
            line_corrections,
        )
        mapped = map_lines(lines, transform, [canvas_container], line_corrections)
        qa = _qa_for_lines(lines, mapped, validation.width_px, validation.height_px)
        if args.mode == "review":
            qa["manual_review_items"] = [
                {"checkpoint": "full_image", "status": "pending"},
                {"checkpoint": "background_geometry", "status": "pending"},
                {"checkpoint": "text_image_and_ocr", "status": "pending"},
                {"checkpoint": "ppt_render", "status": "pending"},
            ]
        spec = replace(spec, qa=qa)
        page_json = write_page_spec(spec, args.output_dir / "page.json")

        if qa["status"] == "failed":
            _remove_stale_outputs(args.output_dir)
            _write_qa(args.output_dir, qa)
            return 1

        pptx = args.output_dir / "page.pptx"
        subprocess.run(
            [
                "node", str(PROJECT_ROOT / "scripts" / "render_ppt.mjs"),
                "--json", str(page_json), "--background", str(args.background),
                "--out", str(pptx),
            ],
            check=True,
        )
        subprocess.run(
            [sys.executable, str(RENDER_SLIDES), str(pptx), "--output_dir", str(args.output_dir)],
            check=True,
        )
        overflow = subprocess.run(
            [sys.executable, str(SLIDES_TEST), str(pptx)],
            text=True,
            capture_output=True,
        )
        qa["checks"]["overflow_check"] = {
            "passed": overflow.returncode == 0,
            "output": (overflow.stdout + overflow.stderr).strip(),
        }
        if overflow.returncode != 0:
            qa["status"] = "failed"
            qa["failed_items"].append(
                {"rule": "ppt_overflow", "message": "slides_test.py reported overflow"}
            )
        if qa["status"] == "failed":
            _remove_stale_outputs(args.output_dir)
        else:
            write_page_spec(replace(spec, qa=qa), page_json)
        _write_qa(args.output_dir, qa)
        return 0 if qa["status"] != "failed" else 1
    except Exception as error:
        _remove_stale_outputs(args.output_dir)
        _write_qa(
            args.output_dir,
            {
                "status": "failed",
                "review_items": [],
                "failed_items": [{"rule": "pipeline", "message": str(error)}],
            },
        )
        print(error, file=sys.stderr)
        return 1


def _validate_font_corrections(corrections: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    failures = []
    for line_id, correction in corrections.items():
        scale = correction.get("font_scale", 1.0)
        if not isinstance(scale, (int, float)) or abs(scale - 1.0) > 0.0300001:
            failures.append({
                "rule": "font_correction_limit", "line_id": line_id, "value": scale,
                "message": "font correction exceeds the 3% single-step limit",
            })
        cumulative = correction.get("cumulative_font_scale", scale)
        if isinstance(cumulative, (int, float)) and abs(cumulative - 1.0) > 0.0800001:
            failures.append({
                "rule": "font_correction_limit", "line_id": line_id, "value": cumulative,
                "message": "font correction exceeds the 8% cumulative limit",
            })
    return failures


def _remove_stale_outputs(output_dir: Path) -> None:
    for name in ("page.json", "page.pptx", "slide-1.png"):
        (output_dir / name).unlink(missing_ok=True)
    for path in output_dir.glob("rendered*.png"):
        if path.is_file():
            path.unlink()


if __name__ == "__main__":
    raise SystemExit(run(parse_args()))
