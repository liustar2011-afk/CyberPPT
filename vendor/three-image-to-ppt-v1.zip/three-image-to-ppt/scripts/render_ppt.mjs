#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

async function loadArtifactTool() {
  const runtimeModules = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
  if (runtimeModules) {
    const entry = path.join(runtimeModules, "@oai", "artifact-tool", "dist", "artifact_tool.mjs");
    try {
      await fs.access(entry);
      return import(pathToFileURL(entry).href);
    } catch {
      // Fall through to normal package resolution for standalone installations.
    }
  }
  return import("@oai/artifact-tool");
}

const { Presentation, PresentationFile } = await loadArtifactTool();

const SLIDE_WIDTH = 1280;
const SLIDE_HEIGHT = 720;

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 2) {
    const flag = argv[index];
    const value = argv[index + 1];
    if (!flag?.startsWith("--") || value === undefined) {
      throw new Error("Usage: render_ppt.mjs --json page.json --background background.png --out page.pptx");
    }
    result[flag.slice(2)] = value;
  }
  for (const required of ["json", "background", "out"]) {
    if (!result[required]) throw new Error(`Missing required argument: --${required}`);
  }
  return result;
}

function contentType(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  if (extension === ".jpg" || extension === ".jpeg") return "image/jpeg";
  if (extension === ".webp") return "image/webp";
  return "image/png";
}

function linePosition(line, page) {
  const box = line.target?.bbox_px ?? line.bbox;
  return {
    left: (box.x / page.width_px) * SLIDE_WIDTH,
    top: (box.y / page.height_px) * SLIDE_HEIGHT,
    width: (box.width / page.width_px) * SLIDE_WIDTH,
    height: (box.height / page.height_px) * SLIDE_HEIGHT,
  };
}

function runStyle(style = {}) {
  const normalized = { typeface: style.typeface ?? style.fontFamily ?? style.font_family ?? "Microsoft YaHei" };
  for (const key of ["bold", "italic", "underline", "color"]) {
    if (style[key] !== undefined) normalized[key] = style[key];
  }
  if (style.font_size !== undefined) normalized.fontSize = `${style.font_size}px`;
  if (style.weight !== undefined) normalized.bold = style.weight === "bold" || Number(style.weight) >= 600;
  if (style.fontSize !== undefined) {
    normalized.fontSize = typeof style.fontSize === "number" ? `${style.fontSize}px` : style.fontSize;
  } else if (style.fontSizePt !== undefined) {
    normalized.fontSize = `${style.fontSizePt}pt`;
  }
  return normalized;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const pageSpec = JSON.parse(await fs.readFile(args.json, "utf8"));
  const presentation = Presentation.create({
    slideSize: { width: SLIDE_WIDTH, height: SLIDE_HEIGHT },
  });
  const slide = presentation.slides.add();

  slide.images.add({
    blob: new Uint8Array(await fs.readFile(args.background)),
    contentType: contentType(args.background),
    alt: "Reconstructed slide background",
    position: { left: 0, top: 0, width: SLIDE_WIDTH, height: SLIDE_HEIGHT },
  });

  for (const line of pageSpec.text_lines) {
    if (/\r|\n/.test(line.text) || line.runs?.some((run) => /\r|\n/.test(run.text))) {
      throw new Error(`Visual line ${line.line_id} must not contain a newline`);
    }
    const textbox = slide.shapes.add({
      geometry: "textbox",
      name: `text-${pageSpec.page.page_id}-${line.line_id}`,
      position: linePosition(line, pageSpec.page),
      fill: "none",
      line: { style: "solid", fill: "none", width: 0 },
    });
    textbox.text = line.runs?.length
      ? line.runs.map((run) => ({ run: run.text, textStyle: runStyle(run.style) }))
      : [{ run: line.text, textStyle: { typeface: "Microsoft YaHei" } }];
    textbox.text.style = {
      insets: { top: 0, right: 0, bottom: 0, left: 0 },
      wrap: "none",
      autoFit: "none",
    };
  }

  await fs.mkdir(path.dirname(path.resolve(args.out)), { recursive: true });
  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(args.out);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
